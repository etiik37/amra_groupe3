/**
 * @private
 */
Ext.define('Ext.device.globalization.Simulator', {
    extend: 'Ext.device.globalization.Abstract'
});
