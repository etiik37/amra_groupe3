/**
 * @private
 */
Ext.define('Ext.device.storage.Simulator', {
    extend: 'Ext.device.storage.HTML5.HTML5'
});
